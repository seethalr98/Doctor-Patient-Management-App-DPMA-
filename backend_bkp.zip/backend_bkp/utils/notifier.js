// backend/utils/notifier.js

const notifyDoctor = (doctorName, appointmentDetails) => {
    console.log(`📢 Notification: Dr. ${doctorName}, you have a new appointment!`);
    console.log(`🗓️  Date: ${appointmentDetails.date}`);
    console.log(`⏰  Time: ${appointmentDetails.time}`);
    console.log(`👤  Patient: ${appointmentDetails.patientEmail}`);
  };
  
  module.exports = {
    notifyDoctor,
  };
  
const jwt = require('jsonwebtoken');

// ✅ Middleware to extract user ID and role from JWT
const protect = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (authHeader && authHeader.startsWith('Bearer')) {
    try {
      const token = authHeader.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');

      // ✅ Attach user info for downstream middleware
      req.user = {
        id: decoded.id || decoded.userId,
        role: decoded.role
      };

      return next();
    } catch (err) {
      console.error('❌ Token error:', err.message);
      return res.status(401).json({ message: 'Not authorized, token failed' });
    }
  }

  return res.status(401).json({ message: 'Not authorized, no token' });
};

// ✅ Middleware to enforce role-based access control
const authorizeRoles = (...allowedRoles) => {
  return (req, res, next) => {
    console.log('🔐 ROLE CHECK - user role:', req.user?.role);

    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Access denied: insufficient role' });
    }

    next();
  };
};

module.exports = {
  protect,
  authorizeRoles
};

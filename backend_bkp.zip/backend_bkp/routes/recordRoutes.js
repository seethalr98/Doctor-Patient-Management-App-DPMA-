console.log("✅ recordRoutes.js loaded");
const express = require('express');
const router = express.Router();

const { protect, authorizeRoles } = require('../middleware/authMiddleware');
const {
  getRecordsByPatientId,
  addMedicalRecord
} = require('../controllers/recordController');

// ✅ DEBUG log before role check
router.get(
  '/:patientEmail',
  protect,
  (req, res, next) => {
    console.log('🔍 DEBUG - req.user:', req.user);
    next();
  },
  authorizeRoles('doctor'),
  getRecordsByPatientId
);

// ✅ Add record route (protected)
router.post(
  '/',
  protect,
  authorizeRoles('doctor'),
  addMedicalRecord
);

module.exports = router;

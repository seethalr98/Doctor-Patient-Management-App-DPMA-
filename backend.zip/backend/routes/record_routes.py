from flask import Blueprint, request, jsonify
from services.record_service import MedicalRecordService
from design_patterns.proxy.medical_record_proxy import RealMedicalRecord, MedicalRecordProxy

record_bp = Blueprint('records', __name__)
record_service = MedicalRecordService()

@record_bp.route('/<patient>', methods=['GET'])
def get_records(patient):
    role = request.args.get("role", "patient")  # Pass ?role=doctor or patient

    data = record_service.get_records(patient)
    real_record = RealMedicalRecord(data)
    proxy = MedicalRecordProxy(real_record, role)

    return jsonify({"records": proxy.view()})

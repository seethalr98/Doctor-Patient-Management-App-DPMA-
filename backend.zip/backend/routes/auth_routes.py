from flask import Blueprint, request, jsonify
from services.auth_service import AuthService

auth_bp = Blueprint('auth', __name__)
auth_service = AuthService()

@auth_bp.route('/register', methods=['POST'])  # ✅ /register matches /api/auth/register
def register():
    data = request.get_json()
    name = data.get("name")
    email = data.get("email")
    password = data.get("password")
    role = data.get("role")

    if role not in ["doctor", "patient"]:
        return jsonify({"error": "Invalid role"}), 400

    user = auth_service.register_user(name, email, password, role)
    return jsonify(user), 201


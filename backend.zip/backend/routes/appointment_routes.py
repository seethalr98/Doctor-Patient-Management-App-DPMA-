from flask import Blueprint, request, jsonify
from services.appointment_service import AppointmentService
from design_patterns.observer.notifier import AppointmentNotifier, DoctorObserver

appointment_bp = Blueprint('appointments', __name__)
appointment_service = AppointmentService()
notifier = AppointmentNotifier()

@appointment_bp.route('/create', methods=['POST'])
def create_appointment():
    data = request.get_json()
    doctor_name = data["doctor"]
    patient_name = data["patient"]
    date = data["date"]
    time = data["time"]
    reason = data["reason"]

    # Observer Pattern
    observer = DoctorObserver(f"{doctor_name}@email.com")
    notifier.register(observer)

    appointment = appointment_service.create_appointment(doctor_name, patient_name, date, time, reason)
    notifier.notify_all(appointment)

    return jsonify(appointment), 201

@appointment_bp.route('/', methods=['GET'])
def get_appointments():
    return jsonify(appointment_service.get_all_appointments())

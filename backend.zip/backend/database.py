# Simulated in-memory database (if needed)
USERS = []
APPOINTMENTS = []
RECORDS = {}

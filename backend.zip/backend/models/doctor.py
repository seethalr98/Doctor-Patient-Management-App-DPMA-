class Doctor:
    def __init__(self, name, email, specialization):
        self.name = name
        self.email = email
        self.specialization = specialization

    def view_profile(self):
        return {
            "role": "doctor",
            "name": self.name,
            "email": self.email,
            "specialization": self.specialization
        }

class Patient:
    def __init__(self, name, email, history=None):
        self.name = name
        self.email = email
        self.medical_history = history if history else []

    def view_profile(self):
        return {
            "role": "patient",
            "name": self.name,
            "email": self.email,
            "medical_history": self.medical_history
        }

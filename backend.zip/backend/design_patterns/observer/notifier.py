class AppointmentNotifier:
    def __init__(self):
        self._observers = []

    def attach(self, observer):
        self._observers.append(observer)

    def notify(self, appointment):
        for observer in self._observers:
            observer.update(appointment)

class DoctorObserver:
    def update(self, appointment):
        print(f"🔔 Doctor notified of new appointment: {appointment}")

# backend/design_patterns/proxy/medical_record_proxy.py

class RealMedicalRecord:
    def __init__(self):
        self._records = {}

    def get_record(self, patient_id):
        return self._records.get(patient_id, "No record found.")

    def add_record(self, patient_id, data):
        self._records[patient_id] = data


class MedicalRecordProxy:
    def __init__(self):
        self._real_record = RealMedicalRecord()

    def get_record(self, patient_id, role):
        if role != "doctor":
            return "Access Denied: Only doctors can view medical records"
        return self._real_record.get_record(patient_id)

    def add_record(self, patient_id, data, role):
        if role != "doctor":
            return "Access Denied: Only doctors can add medical records"
        return self._real_record.add_record(patient_id, data)

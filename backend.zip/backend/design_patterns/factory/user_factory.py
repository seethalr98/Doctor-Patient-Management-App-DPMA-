from models.doctor import Doctor
from models.patient import Patient

class UserFactory:
    @staticmethod
    def create_user(role, **kwargs):
        if role == "doctor":
            return Doctor(kwargs["name"], kwargs["email"], kwargs.get("specialization", "General"))
        elif role == "patient":
            return Patient(kwargs["name"], kwargs["email"], kwargs.get("history", []))
        else:
            raise ValueError("Invalid user role")

class MedicalRecordService:
    def __init__(self):
        # Placeholder for medical records (could be a list or DB in future)
        self.records = []

    def add_record(self, patient_id, details):
        record = {
            "patient_id": patient_id,
            "details": details
        }
        self.records.append(record)
        return record

    def get_records_by_patient(self, patient_id):
        return [r for r in self.records if r["patient_id"] == patient_id]

from design_patterns.factory.user_factory import UserFactory

class AuthService:
    def register_user(self, role, **kwargs):
        # Use the factory to create doctor or patient based on role
        return UserFactory.create_user(role, **kwargs)

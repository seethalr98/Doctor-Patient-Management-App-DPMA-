class AppointmentService:
    def __init__(self):
        self.appointments = []

    def create_appointment(self, doctor_name, date, time, reason, patient_email):
        appointment = {
            "doctor": doctor_name,
            "date": date,
            "time": time,
            "reason": reason,
            "patient_email": patient_email
        }
        self.appointments.append(appointment)
        return appointment

    def get_appointments_for_doctor(self, doctor_name):
        return [appt for appt in self.appointments if appt["doctor"] == doctor_name]

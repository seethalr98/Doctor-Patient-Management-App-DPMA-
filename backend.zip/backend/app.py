from flask import Flask
from flask_cors import CORS

from routes.auth_routes import auth_bp
from routes.appointment_routes import appointment_bp
from routes.record_routes import record_bp

def create_app():
    app = Flask(__name__)

    # ✅ Apply CORS globally for React running on localhost:3000
    CORS(app, resources={r"/api/*": {"origins": "http://localhost:3000"}})

    # Register routes
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(appointment_bp, url_prefix='/appointments')
    app.register_blueprint(record_bp, url_prefix='/records')

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, port=5001)
